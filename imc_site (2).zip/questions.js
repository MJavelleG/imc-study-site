
// Question bank
const questionBank = {
  chapter1: [
    {id:'1-1', q:'Who can legally carry out regulated activities under FSMA 2000?', a:'Authorised or exempt persons only.'},
    {id:'1-2', q:'What are the two main types of authorisation under FSMA 2000?', a:'Part 4A permission and Passporting.'},
    {id:'1-3', q:'What manual provides guidance on whether authorisation is needed?', a:"FCA’s Perimeter Guidance Manual (PERG)."},
    {id:'1-4', q:'Do individuals become authorised under FSMA 2000?', a:'No – individuals become approved persons.'},
    {id:'1-5', q:'Which EU directive allowed investment services firms to passport into the UK?', a:'MiFID.'}
  ],
  chapter2: [
    {id:'2-1', q:'Placeholder question for Chapter 2', a:'Placeholder answer'}
  ],
  chapter3: [
    {id:'3-1', q:'Placeholder question for Chapter 3', a:'Placeholder answer'}
  ],
  chapter4: [
    {id:'4-1', q:'Placeholder question for Chapter 4', a:'Placeholder answer'}
  ],
  chapter5: [
    {id:'5-1', q:'Placeholder question for Chapter 5', a:'Placeholder answer'}
  ],
  chapter6: [
    {id:'6-1', q:'Placeholder question for Chapter 6', a:'Placeholder answer'}
  ],
  chapter7: [
    {id:'7-1', q:'Placeholder question for Chapter 7', a:'Placeholder answer'}
  ],
  chapter8: [
    {id:'8-1', q:'Placeholder question for Chapter 8', a:'Placeholder answer'}
  ],
  chapter9: [
    {id:'9-1', q:'Placeholder question for Chapter 9', a:'Placeholder answer'}
  ],
  chapter10: [
    {id:'10-1', q:'Placeholder question for Chapter 10', a:'Placeholder answer'}
  ]
};
